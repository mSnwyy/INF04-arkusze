'''
***********************************************
nazwa funkcji: inputPesel
opis funkcji: Pobiera numer PESEL od użytkownika i sprawdza jego poprawność.
parametry: Brak
zwracany typ i opis: list - lista zawierająca cyfry PESEL.
autor: mSnwyy
***********************************************
'''
def inputPesel():
    while True:
        pesel = input('Insert PESEL: ')
        if not pesel.isdigit():
            print("PESEL must contain digits only.")
        elif len(pesel) != 11:
            print("PESEL must be exactly 11 digits long.")
        else:
            pesel = list(pesel) 
            break
    return pesel

'''
***********************************************
nazwa funkcji: fakePeselCheck
opis funkcji: Sprawdza poprawność numeru PESEL na podstawie sumy kontrolnej.
parametry: pesel - lista cyfr numeru PESEL.
zwracany typ i opis: bool - True, jeśli PESEL jest prawidłowy, False w przeciwnym razie.
autor: mSnwyy
***********************************************
'''

def fakePeselCheck(pesel):
    weights = {
        0: 1,
        1: 3,
        2: 7,
        3: 9,
        4: 1,
        5: 3,
        6: 7,
        7: 9,
        8: 1,
        9: 3
    }
    results = []
    for i in range(10): 
        digit = pesel[i]
        result = int(digit) * weights[i] 
        results.append(result)
    S = sum(results)
    M = S % 10
    if M == 0:
        R = 0
    else:
        R = 10 - M
    if R == int(pesel[10]):
        print("Real pesel")
        return True
    else:
        print("Fake pesel")
        return False

'''
***********************************************
nazwa funkcji: sex
opis funkcji: Określa płeć na podstawie numeru PESEL.
parametry: pesel - lista cyfr numeru PESEL.
zwracany typ i opis: None - funkcja nie zwraca wartości, tylko wyświetla wynik.
autor: mSnwyy
***********************************************
'''
def sex(pesel):
    if int(pesel[9]) % 2 == 0:  
        print("Female")
    else:
        print("Male")

pesel = inputPesel()
sex(pesel)
fakePeselCheck(pesel)