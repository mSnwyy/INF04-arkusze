import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
"""
**********************************************
nazwa funkcji: update_images
opis funkcji: Wczytuje i aktualizuje obrazy na podstawie numeru wpisanego w polu tekstowym.
parametry: event - opcjonalny parametr zdarzenia (domyślnie None)
zwracany typ i opis: None - funkcja nie zwraca wartości.
autor: mSnwyy
***********************************************
"""
def update_images(event=None):
    numer = entry_numer.get()
    try:

        img_zdjecie = Image.open(f'{numer}-zdjecie.jpg')
        img_odcisk = Image.open(f'{numer}-odcisk.jpg')
        img_zdjecie = img_zdjecie.resize((180, 180))
        img_odcisk = img_odcisk.resize((180, 180))

        photo_zdjecie = ImageTk.PhotoImage(img_zdjecie)
        photo_odcisk = ImageTk.PhotoImage(img_odcisk)

        label_zdjecie.config(image=photo_zdjecie)
        label_odcisk.config(image=photo_odcisk)
        label_zdjecie.image = photo_zdjecie  
        label_odcisk.image = photo_odcisk  
    except FileNotFoundError:

        label_zdjecie.config(image="")
        label_odcisk.config(image="")
"""
***********************************************
nazwa funkcji: on_ok_click
opis funkcji: Pobiera dane użytkownika i wyświetla je w oknie dialogowym.
parametry: Brak
zwracany typ i opis: None - funkcja nie zwraca wartości.
autor: mSnwyy
***********************************************
"""
def on_ok_click():
    kolor_oczu = kolor_oczu_var.get()
    imie = entry_imie.get()
    nazwisko = entry_nazwisko.get()
    if imie and nazwisko:
        messagebox.showinfo("Dane", f'{imie} {nazwisko}, kolor oczu: {kolor_oczu}')
    else:
        messagebox.showinfo("Blad", f'Wprowadz dane')


root = tk.Tk()
root.title("Wprowadzanie danych do paszportu. Wykonal mSnwyy")
root.geometry("800x500")
root.configure(bg="#5F9EA0")

frame = tk.Frame(root, bg="#5F9EA0")
frame.grid(row=0, column=0, padx=20, pady=20)

tk.Label(frame, text="Numer", bg="#5F9EA0").grid(row=0, column=0, sticky="w")
entry_numer = tk.Entry(frame, bg="#F0FFFF")
entry_numer.grid(row=0, column=1, pady=5)
entry_numer.bind("<FocusOut>", update_images) 

tk.Label(frame, text="Imie", bg="#5F9EA0").grid(row=1, column=0, sticky="w")
entry_imie = tk.Entry(frame, bg="#F0FFFF")
entry_imie.grid(row=1, column=1, pady=5)

tk.Label(frame, text="Nazwisko", bg="#5F9EA0").grid(row=2, column=0, sticky="w")
entry_nazwisko = tk.Entry(frame, bg="#F0FFFF")
entry_nazwisko.grid(row=2, column=1, pady=5)

tk.Label(frame, text="Kolor oczu", bg="#5F9EA0").grid(row=3, column=0, sticky="w")
kolor_oczu_var = tk.StringVar(value="niebieskie")
tk.Radiobutton(frame, text="niebieskie", variable=kolor_oczu_var, value="niebieskie", bg="#5F9EA0").grid(row=4, column=0, sticky="w")
tk.Radiobutton(frame, text="zielone", variable=kolor_oczu_var, value="zielone", bg="#5F9EA0").grid(row=5, column=0, sticky="w")
tk.Radiobutton(frame, text="piwne", variable=kolor_oczu_var, value="piwne", bg="#5F9EA0").grid(row=6, column=0, sticky="w")

tk.Button(frame, text="OK", command=on_ok_click, bg="#F0FFFF", width=30).grid(row=7, column=2, columnspan=2, pady=10)

label_zdjecie = tk.Label(frame, bg="#5F9EA0")
label_zdjecie.grid(row=1, column=2, rowspan=3, padx=20)

label_odcisk = tk.Label(frame, bg="#5F9EA0")
label_odcisk.grid(row=1, column=3, rowspan=3, padx=20)

root.mainloop()